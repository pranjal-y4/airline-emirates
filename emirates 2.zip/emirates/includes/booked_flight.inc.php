<?php
	session_start();
	
	function booked_flights(){
		
	}